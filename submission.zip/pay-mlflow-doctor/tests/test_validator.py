import unittest
from tempfile import TemporaryDirectory
from pathlib import Path

from paymlflow_doctor.validators import validate_project


class ValidatorTest(unittest.TestCase):
    def test_broken_project_is_blocked(self):
        report = validate_project("sample-data/broken-mlflow-project")
        self.assertEqual(report.risk_level, "blocked")
        self.assertTrue(any(finding.id == "PYTHON_VERSION_MISMATCH" for finding in report.findings))
        self.assertTrue(any(finding.id == "KSERVE_LOCAL_STORAGE_URI" for finding in report.findings))
        self.assertTrue(any(finding.id == "ARTIFACT_PATH_MISSING" for finding in report.findings))

    def test_healthy_project_has_no_blockers(self):
        report = validate_project("sample-data/healthy-mlflow-project")
        self.assertGreaterEqual(report.score, 90)
        self.assertFalse(any(finding.severity in {"critical", "high"} for finding in report.findings))

    def test_policy_pack_flags_broken_project(self):
        report = validate_project("sample-data/broken-mlflow-project", "policies/kakaopay-mlops-policy.yaml")
        self.assertTrue(any(finding.id == "POLICY_PYTHON_VERSION_NOT_APPROVED" for finding in report.findings))
        self.assertTrue(any(finding.id == "POLICY_BLOCKED_URI_PREFIX" for finding in report.findings))

    def test_policy_pack_allows_healthy_project(self):
        report = validate_project("sample-data/healthy-mlflow-project", "policies/kakaopay-mlops-policy.yaml")
        self.assertFalse(any(finding.id.startswith("POLICY_") for finding in report.findings))

    def test_credential_values_are_masked_and_blocked(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "MLmodel").write_text("python_version: 3.11\n", encoding="utf-8")
            (root / "requirements.txt").write_text("mlflow==2.12.1\n", encoding="utf-8")
            (root / ".env").write_text("DB_PASSWORD=demo-value-do-not-use\n", encoding="utf-8")
            report = validate_project(root)
            finding = next(item for item in report.findings if item.id == "CREDENTIAL_VALUE_PRESENT")
            self.assertEqual(finding.severity, "critical")
            self.assertNotIn("demo-value-do-not-use", finding.message)

    def test_imports_must_be_declared_in_requirements(self):
        report = validate_project("sample-data/broken-mlflow-project")
        self.assertTrue(any(finding.id == "IMPORT_NOT_DECLARED" for finding in report.findings))

    def test_current_python_env_check_uses_installed_package_list(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "MLmodel").write_text("python_version: 3.11\n", encoding="utf-8")
            (root / "requirements.txt").write_text("package-that-should-not-exist-paymlflow==1.0.0\n", encoding="utf-8")
            report = validate_project(root, check_python_env=True)
            self.assertTrue(any(finding.id == "PYTHON_ENV_PACKAGE_MISSING" for finding in report.findings))


if __name__ == "__main__":
    unittest.main()
